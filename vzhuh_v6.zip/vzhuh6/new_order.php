<?php
$title = 'Новый заказ';
require 'db.php';
require 'header.php';
must_login();

$err = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $spread  = trim($_POST['spread']    ?? '');
    $date    = trim($_POST['pred_date'] ?? '');
    $payment = trim($_POST['payment']   ?? '');
    $phone   = trim($_POST['phone']     ?? '');

    if (!$spread)  $err['spread']  = 'Выберите вид расклада';
    if (!$date)    $err['date']    = 'Укажите дату';
    if (!$payment) $err['payment'] = 'Выберите способ оплаты';
    if (!$phone)   $err['phone']   = 'Введите телефон';

    if (empty($err)) {
        $pdo->prepare('INSERT INTO orders (user_id,spread_type,pred_date,payment,phone) VALUES (?,?,?,?,?)')
            ->execute([$_SESSION['uid'], $spread, $date, $payment, $phone]);
        header('Location: /vzhuh/orders.php'); exit;
    }
}
?>

<div class="form-wrap">
  <h1>Заказать расклад</h1>
  <form method="POST">

    <label>Вид расклада</label>
    <select name="spread">
      <option value="">— Выберите —</option>
      <option value="Любовь"     <?= ($_POST['spread']??'')==='Любовь'    ?'selected':''?>>Любовь</option>
      <option value="Финансы"    <?= ($_POST['spread']??'')==='Финансы'   ?'selected':''?>>Финансы</option>
      <option value="Творчество" <?= ($_POST['spread']??'')==='Творчество'?'selected':''?>>Творчество</option>
    </select>
    <?php if (!empty($err['spread'])): ?><span class="err-msg"><?= $err['spread'] ?></span><?php endif; ?>

    <label>Дата предсказания</label>
    <input type="date" name="pred_date" value="<?= $_POST['pred_date'] ?? '' ?>">
    <?php if (!empty($err['date'])): ?><span class="err-msg"><?= $err['date'] ?></span><?php endif; ?>

    <label>Способ оплаты</label>
    <select name="payment">
      <option value="">— Выберите —</option>
      <option value="cash"     <?= ($_POST['payment']??'')==='cash'    ?'selected':''?>>Наличными</option>
      <option value="transfer" <?= ($_POST['payment']??'')==='transfer'?'selected':''?>>Переводом по номеру телефона</option>
    </select>
    <?php if (!empty($err['payment'])): ?><span class="err-msg"><?= $err['payment'] ?></span><?php endif; ?>

    <label>Телефон для связи</label>
    <input type="text" name="phone" placeholder="+7 999 123-45-67" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
    <?php if (!empty($err['phone'])): ?><span class="err-msg"><?= $err['phone'] ?></span><?php endif; ?>

    <div class="form-btns">
      <a href="/vzhuh/orders.php" class="btn gray">Отмена</a>
      <button type="submit" class="btn">Отправить</button>
    </div>
  </form>
</div>

<?php require 'footer.php'; ?>
