<?php
$title = 'Регистрация';
require 'db.php';
require 'header.php';

$err = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $pass  = trim($_POST['pass']  ?? '');
    $fio   = trim($_POST['fio']   ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if (!preg_match('/^[a-zA-Z0-9]{6,}$/', $login))
        $err['login'] = 'Только латиница и цифры, минимум 6 символов';
    if (strlen($pass) < 8)
        $err['pass'] = 'Минимум 8 символов';
    if (!preg_match('/^[а-яёА-ЯЁ\s]+$/u', $fio))
        $err['fio'] = 'Только кириллица и пробелы';
    if (empty($phone))
        $err['phone'] = 'Введите телефон';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
        $err['email'] = 'Некорректный email';

    if (empty($err)) {
        $s = $pdo->prepare('SELECT id FROM users WHERE login = ?');
        $s->execute([$login]);
        if ($s->fetch()) {
            $err['login'] = 'Этот логин уже занят';
        } else {
            $pdo->prepare('INSERT INTO users (login,password,fio,phone,email) VALUES (?,?,?,?,?)')
                ->execute([$login, password_hash($pass, PASSWORD_DEFAULT), $fio, $phone, $email]);
            header('Location: /vzhuh/login.php?ok=1');
            exit;
        }
    }
}
?>

<div class="auth-wrap">
  <div class="auth-box">
    <h1>Регистрация</h1>
    <form method="POST">

      <label>Логин (латиница+цифры, мин. 6)</label>
      <input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
      <?php if (!empty($err['login'])): ?><span class="err-msg"><?= $err['login'] ?></span><?php endif; ?>

      <label>Пароль (минимум 8 символов)</label>
      <input type="password" name="pass">
      <?php if (!empty($err['pass'])): ?><span class="err-msg"><?= $err['pass'] ?></span><?php endif; ?>

      <label>ФИО (только кириллица)</label>
      <input type="text" name="fio" value="<?= htmlspecialchars($_POST['fio'] ?? '') ?>">
      <?php if (!empty($err['fio'])): ?><span class="err-msg"><?= $err['fio'] ?></span><?php endif; ?>

      <label>Телефон</label>
      <input type="text" name="phone" placeholder="+7 999 123-45-67" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
      <?php if (!empty($err['phone'])): ?><span class="err-msg"><?= $err['phone'] ?></span><?php endif; ?>

      <label>Email</label>
      <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      <?php if (!empty($err['email'])): ?><span class="err-msg"><?= $err['email'] ?></span><?php endif; ?>

      <button type="submit" class="btn full">Зарегистрироваться</button>
    </form>
    <p class="sw">Уже есть аккаунт? <a href="/vzhuh/login.php">Войти</a></p>
  </div>
</div>

<?php require 'footer.php'; ?>
