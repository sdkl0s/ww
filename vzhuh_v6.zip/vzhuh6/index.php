<?php $title = 'Вжух — Гадание на картах Таро'; require 'header.php'; ?>

<div class="slider">
  <div class="slides" id="slides">
    <div class="slide sl1">
      <h1>Узнай своё будущее</h1>
      <p>Расклады карт Таро от опытных мастеров</p>
      <a href="/vzhuh/register.php" class="btn big">Начать</a>
    </div>
    <div class="slide sl2">
      <h1>Любовный расклад</h1>
      <p>Узнай что ждёт тебя в личной жизни</p>
      <a href="/vzhuh/register.php" class="btn big">Заказать</a>
    </div>
    <div class="slide sl3">
      <h1>Финансовый расклад</h1>
      <p>Карты откроют путь к благополучию</p>
      <a href="/vzhuh/register.php" class="btn big">Узнать</a>
    </div>
    <div class="slide sl4">
      <h1>Творческий расклад</h1>
      <p>Раскрой свой потенциал с помощью Таро</p>
      <a href="/vzhuh/register.php" class="btn big">Попробовать</a>
    </div>
  </div>
  <button class="arrow lft" onclick="move(-1)">&lsaquo;</button>
  <button class="arrow rgt" onclick="move(1)">&rsaquo;</button>
  <div class="dots">
    <span class="dot on" onclick="go(0)"></span>
    <span class="dot"    onclick="go(1)"></span>
    <span class="dot"    onclick="go(2)"></span>
    <span class="dot"    onclick="go(3)"></span>
  </div>
</div>

<section class="feats">
  <h2>Что мы предлагаем</h2>
  <div class="grid3">
    <div class="card">
      <h3>Расклады Таро</h3>
      <p>Любовь, финансы, творчество — выбери свой путь</p>
    </div>
    <div class="card">
      <h3>Удобная запись</h3>
      <p>Выбери дату и способ оплаты онлайн</p>
    </div>
    <div class="card">
      <h3>Отзывы клиентов</h3>
      <p>Оставь отзыв после получения предсказания</p>
    </div>
  </div>
</section>

<script>
let cur = 0, total = 4;
function go(n) {
  cur = n;
  document.getElementById('slides').style.transform = 'translateX(-' + cur*100 + '%)';
  document.querySelectorAll('.dot').forEach((d,i) => d.classList.toggle('on', i===cur));
}
function move(d) { go((cur+d+total)%total); }
setInterval(() => move(1), 3000);
</script>

<?php require 'footer.php'; ?>
