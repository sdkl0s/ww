<?php
$title = 'Мои заказы';
require 'db.php';
require 'header.php';
must_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['oid'])) {
    $review = trim($_POST['review'] ?? '');
    if ($review) {
        $pdo->prepare('UPDATE orders SET review=? WHERE id=? AND user_id=? AND status="done"')
            ->execute([$review, (int)$_POST['oid'], $_SESSION['uid']]);
    }
    header('Location: /vzhuh/orders.php'); exit;
}

$s = $pdo->prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC');
$s->execute([$_SESSION['uid']]);
$orders = $s->fetchAll();

$sl = ['new'=>'Новый','in_progress'=>'В работе','done'=>'Предсказание готово'];
$sc = ['new'=>'blue','in_progress'=>'yellow','done'=>'green'];
$pt = ['cash'=>'Наличными','transfer'=>'Переводом'];
?>

<div class="page-head">
  <h1>Мои заказы</h1>
  <a href="/vzhuh/new_order.php" class="btn">+ Заказать расклад</a>
</div>

<?php if (!$orders): ?>
  <div class="empty">
    <p>Заказов пока нет</p>
    <a href="/vzhuh/new_order.php" class="btn">Создать первый</a>
  </div>
<?php else: ?>
  <?php foreach ($orders as $o): ?>
  <div class="order-card">
    <div class="order-top">
      <strong><?= htmlspecialchars($o['spread_type']) ?></strong>
      <span class="badge <?= $sc[$o['status']] ?>"><?= $sl[$o['status']] ?></span>
    </div>
    <div class="order-meta">
      <span>Дата: <?= $o['pred_date'] ?></span>
      <span>Оплата: <?= $pt[$o['payment']] ?></span>
      <span>Телефон: <?= htmlspecialchars($o['phone']) ?></span>
      <span>Создан: <?= date('d.m.Y', strtotime($o['created_at'])) ?></span>
    </div>
    <?php if ($o['review']): ?>
      <div class="review-box">Ваш отзыв: <?= htmlspecialchars($o['review']) ?></div>
    <?php elseif ($o['status'] === 'done'): ?>
      <form method="POST" class="review-form">
        <input type="hidden" name="oid" value="<?= $o['id'] ?>">
        <textarea name="review" rows="2" placeholder="Оставьте отзыв..."></textarea>
        <button type="submit" class="btn small">Отправить отзыв</button>
      </form>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
<?php endif; ?>

<?php require 'footer.php'; ?>
