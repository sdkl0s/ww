<?php
$title = 'Вход';
require 'db.php';
require 'header.php';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $pass  = trim($_POST['pass']  ?? '');

    if (!$login || !$pass) {
        $err = 'Заполните все поля';
    } else {
        $s = $pdo->prepare('SELECT * FROM users WHERE login = ?');
        $s->execute([$login]);
        $u = $s->fetch();

        if ($u) {
            $ok = ($u['role'] === 'admin')
                ? ($pass === $u['password'])
                : password_verify($pass, $u['password']);

            if ($ok) {
                $_SESSION['uid']  = $u['id'];
                $_SESSION['name'] = $u['fio'];
                $_SESSION['role'] = $u['role'];
                header('Location: ' . ($u['role'] === 'admin' ? '/vzhuh/admin/index.php' : '/vzhuh/orders.php'));
                exit;
            }
        }
        $err = 'Неверный логин или пароль';
    }
}
?>

<?php if (isset($_GET['ok'])): ?>
  <div class="alert ok">Регистрация успешна! Войдите.</div>
<?php endif; ?>

<div class="auth-wrap">
  <div class="auth-box">
    <h1>Вход в систему</h1>
    <?php if ($err): ?>
      <div class="alert err"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>
    <form method="POST">
      <label>Логин</label>
      <input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
      <label>Пароль</label>
      <input type="password" name="pass">
      <button type="submit" class="btn full">Войти</button>
    </form>
    <p class="sw">Ещё не зарегистрированы? <a href="/vzhuh/register.php">Регистрация</a></p>
  </div>
</div>

<?php require 'footer.php'; ?>
