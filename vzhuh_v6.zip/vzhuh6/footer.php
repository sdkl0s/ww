</main>
<footer>
  <div class="wrap">
    <p>Вжух &copy; <?= date('Y') ?> — Портал гадания по картам Таро</p>
  </div>
</footer>
</body>
</html>
