<?php
if (session_status() === PHP_SESSION_NONE) session_start();

function logged_in() { return isset($_SESSION['uid']); }
function is_admin()  { return ($_SESSION['role'] ?? '') === 'admin'; }
function must_login(){ if (!logged_in()) { header('Location: /vzhuh/login.php'); exit; } }
function must_admin(){ must_login(); if (!is_admin()) { header('Location: /vzhuh/orders.php'); exit; } }
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $title ?? 'Вжух' ?></title>
  <link rel="stylesheet" href="/vzhuh/style.css">
</head>
<body>
<header>
  <div class="wrap hdr">
    <a class="logo" href="/vzhuh/index.php">Вжух — Таро</a>
    <nav>
      <?php if (logged_in()): ?>
        <a href="/vzhuh/orders.php">Мои заказы</a>
        <a href="/vzhuh/new_order.php" class="btn">+ Заказать</a>
        <?php if (is_admin()): ?>
          <a href="/vzhuh/admin/index.php" class="btn" style="background:#d97706">Админ</a>
        <?php endif; ?>
        <a href="/vzhuh/logout.php" style="color:#f87171">Выйти</a>
      <?php else: ?>
        <a href="/vzhuh/login.php">Войти</a>
        <a href="/vzhuh/register.php" class="btn">Регистрация</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="wrap">
