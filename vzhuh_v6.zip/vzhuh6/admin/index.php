<?php
$title = 'Панель администратора';
require '../db.php';
require '../header.php';
must_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['oid'])) {
    $pdo->prepare('UPDATE orders SET status=? WHERE id=?')
        ->execute([$_POST['status'], (int)$_POST['oid']]);
    header('Location: /vzhuh/admin/index.php'); exit;
}

$all = $pdo->query(
    'SELECT o.*, u.fio, u.login FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC'
)->fetchAll();

$stat = $pdo->query(
    "SELECT COUNT(*) t, SUM(status='new') nw, SUM(status='in_progress') ip, SUM(status='done') dn FROM orders"
)->fetch();

$sl = ['new'=>'Новый','in_progress'=>'В работе','done'=>'Предсказание готово'];
$sc = ['new'=>'blue','in_progress'=>'yellow','done'=>'green'];
$pt = ['cash'=>'Наличными','transfer'=>'Переводом'];
?>

<div class="page-head"><h1>Панель администратора</h1></div>

<div class="stats">
  <div class="stat"><div class="num"><?= $stat['t']  ?></div><div class="lbl">Всего</div></div>
  <div class="stat"><div class="num"><?= $stat['nw'] ?></div><div class="lbl">Новых</div></div>
  <div class="stat"><div class="num"><?= $stat['ip'] ?></div><div class="lbl">В работе</div></div>
  <div class="stat"><div class="num"><?= $stat['dn'] ?></div><div class="lbl">Готово</div></div>
</div>

<div class="tbl-wrap">
  <table>
    <thead>
      <tr>
        <th>#</th><th>Клиент</th><th>Расклад</th><th>Дата</th>
        <th>Оплата</th><th>Телефон</th><th>Статус</th><th>Отзыв</th><th>Изменить</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($all as $o): ?>
    <tr>
      <td><?= $o['id'] ?></td>
      <td>
        <?= htmlspecialchars($o['fio']) ?><br>
        <small style="color:#9ca3af"><?= htmlspecialchars($o['login']) ?></small>
      </td>
      <td><?= htmlspecialchars($o['spread_type']) ?></td>
      <td><?= $o['pred_date'] ?></td>
      <td><?= $pt[$o['payment']] ?></td>
      <td><?= htmlspecialchars($o['phone']) ?></td>
      <td><span class="badge <?= $sc[$o['status']] ?>"><?= $sl[$o['status']] ?></span></td>
      <td style="max-width:140px;font-size:13px">
        <?= $o['review'] ? htmlspecialchars($o['review']) : '<span style="color:#ccc">—</span>' ?>
      </td>
      <td>
        <form method="POST" style="display:flex;gap:5px;align-items:center">
          <input type="hidden" name="oid" value="<?= $o['id'] ?>">
          <select name="status">
            <option value="new"         <?= $o['status']==='new'         ?'selected':'' ?>>Новый</option>
            <option value="in_progress" <?= $o['status']==='in_progress' ?'selected':'' ?>>В работе</option>
            <option value="done"        <?= $o['status']==='done'        ?'selected':'' ?>>Готово</option>
          </select>
          <button type="submit" class="btn small">OK</button>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require '../footer.php'; ?>
