<?php
$title = 'Администратор';
require '../db.php';
require '../header.php';
must_admin();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['oid'])) {
    $pdo->prepare('UPDATE orders SET status=? WHERE id=?')
        ->execute([$_POST['status'], $_POST['oid']]);
    header('Location: /vzhuh/admin/index.php');
    exit;
}

$list = $pdo->query(
    'SELECT o.*, u.fio, u.login FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC'
)->fetchAll();

$stat = $pdo->query(
    "SELECT COUNT(*) t, SUM(status='new') nw, SUM(status='in_progress') ip, SUM(status='done') dn FROM orders"
)->fetch();

$sn = ['new'=>'Новый', 'in_progress'=>'В работе', 'done'=>'Предсказание готово'];
$sc = ['new'=>'b-blue', 'in_progress'=>'b-yellow', 'done'=>'b-green'];
$pn = ['cash'=>'Наличными', 'transfer'=>'Переводом'];
?>

<div class="wrap">
<div class="ph"><h2>Панель администратора</h2></div>

<div class="stats">
  <div class="sbox"><div class="snum"><?= $stat['t']  ?></div><div class="slbl">Всего</div></div>
  <div class="sbox"><div class="snum"><?= $stat['nw'] ?></div><div class="slbl">Новых</div></div>
  <div class="sbox"><div class="snum"><?= $stat['ip'] ?></div><div class="slbl">В работе</div></div>
  <div class="sbox"><div class="snum"><?= $stat['dn'] ?></div><div class="slbl">Готово</div></div>
</div>

<div class="twrap">
<table>
  <thead>
    <tr><th>#</th><th>Клиент</th><th>Расклад</th><th>Дата</th><th>Оплата</th><th>Телефон</th><th>Статус</th><th>Отзыв</th><th>Изменить</th></tr>
  </thead>
  <tbody>
  <?php foreach ($list as $o): ?>
  <tr>
    <td><?= $o['id'] ?></td>
    <td><?= htmlspecialchars($o['fio']) ?><br><small style="color:#9ca3af"><?= htmlspecialchars($o['login']) ?></small></td>
    <td><?= htmlspecialchars($o['spread_type']) ?></td>
    <td><?= $o['pred_date'] ?></td>
    <td><?= $pn[$o['payment']] ?></td>
    <td><?= htmlspecialchars($o['phone']) ?></td>
    <td><span class="badge <?= $sc[$o['status']] ?>"><?= $sn[$o['status']] ?></span></td>
    <td style="max-width:130px"><?= $o['review'] ? htmlspecialchars($o['review']) : '—' ?></td>
    <td>
      <form method="POST" style="display:flex;gap:5px;align-items:center">
        <input type="hidden" name="oid" value="<?= $o['id'] ?>">
        <select name="status">
          <option value="new"         <?= $o['status']=='new'         ? 'selected' : '' ?>>Новый</option>
          <option value="in_progress" <?= $o['status']=='in_progress' ? 'selected' : '' ?>>В работе</option>
          <option value="done"        <?= $o['status']=='done'        ? 'selected' : '' ?>>Готово</option>
        </select>
        <button type="submit" class="btn btn-sm">OK</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>

<?php require '../footer.php'; ?>
