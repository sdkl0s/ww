<?php
$title = 'Новый заказ';
require 'db.php';
require 'header.php';
must_login();

$e = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $spread  = trim($_POST['spread']);
    $date    = trim($_POST['pred_date']);
    $payment = trim($_POST['payment']);
    $phone   = trim($_POST['phone']);

    if (!$spread)  $e['spread']  = 'Выберите расклад';
    if (!$date)    $e['date']    = 'Укажите дату';
    if (!$payment) $e['payment'] = 'Выберите оплату';
    if (!$phone)   $e['phone']   = 'Введите телефон';

    if (empty($e)) {
        $pdo->prepare('INSERT INTO orders (user_id,spread_type,pred_date,payment,phone) VALUES (?,?,?,?,?)')
            ->execute([$_SESSION['uid'], $spread, $date, $payment, $phone]);
        header('Location: /vzhuh/orders.php');
        exit;
    }
}
?>

<div class="wrap">
<div class="fbox wide">
  <h2>Создать заказ</h2>
  <form method="POST">

    <label>Вид расклада</label>
    <select name="spread">
      <option value="">-- Выберите --</option>
      <option value="Любовь"     <?= (($_POST['spread'] ?? '') == 'Любовь')     ? 'selected' : '' ?>>Любовь</option>
      <option value="Финансы"    <?= (($_POST['spread'] ?? '') == 'Финансы')    ? 'selected' : '' ?>>Финансы</option>
      <option value="Творчество" <?= (($_POST['spread'] ?? '') == 'Творчество') ? 'selected' : '' ?>>Творчество</option>
    </select>
    <?php if (!empty($e['spread'])): ?><span class="err"><?= $e['spread'] ?></span><?php endif; ?>

    <label>Дата предсказания</label>
    <input type="date" name="pred_date" value="<?= $_POST['pred_date'] ?? '' ?>">
    <?php if (!empty($e['date'])): ?><span class="err"><?= $e['date'] ?></span><?php endif; ?>

    <label>Способ оплаты</label>
    <select name="payment">
      <option value="">-- Выберите --</option>
      <option value="cash"     <?= (($_POST['payment'] ?? '') == 'cash')     ? 'selected' : '' ?>>Наличными</option>
      <option value="transfer" <?= (($_POST['payment'] ?? '') == 'transfer') ? 'selected' : '' ?>>Переводом</option>
    </select>
    <?php if (!empty($e['payment'])): ?><span class="err"><?= $e['payment'] ?></span><?php endif; ?>

    <label>Телефон для связи</label>
    <input type="text" name="phone" placeholder="89991234567" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
    <?php if (!empty($e['phone'])): ?><span class="err"><?= $e['phone'] ?></span><?php endif; ?>

    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
      <a href="/vzhuh/orders.php" class="btn btn-gray">Отмена</a>
      <button type="submit" class="btn">Отправить</button>
    </div>
  </form>
</div>
</div>

<?php require 'footer.php'; ?>
