<?php
$title = 'Регистрация';
require 'db.php';
require 'header.php';

$e = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = trim($_POST['login']);
    $pass  = trim($_POST['pass']);
    $fio   = trim($_POST['fio']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);

    if (!preg_match('/^[a-zA-Z0-9]{6,}$/', $login)) $e['login'] = 'Только латиница и цифры, минимум 6';
    if (strlen($pass) < 8)                           $e['pass']  = 'Минимум 8 символов';
    if (!preg_match('/^[а-яёА-ЯЁ\s]+$/u', $fio))    $e['fio']   = 'Только кириллица';
    if (empty($phone))                               $e['phone'] = 'Введите телефон';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))  $e['email'] = 'Некорректный email';

    if (empty($e)) {
        $s = $pdo->prepare('SELECT id FROM users WHERE login = ?');
        $s->execute([$login]);
        if ($s->fetch()) {
            $e['login'] = 'Логин уже занят';
        } else {
            $pdo->prepare('INSERT INTO users (login,password,fio,phone,email) VALUES (?,?,?,?,?)')
                ->execute([$login, password_hash($pass, PASSWORD_DEFAULT), $fio, $phone, $email]);
            header('Location: /vzhuh/login.php?ok=1');
            exit;
        }
    }
}
?>

<div class="wrap">
<div class="fbox">
  <h2>Регистрация</h2>
  <form method="POST">

    <label>Логин (латиница+цифры, мин.6)</label>
    <input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
    <?php if (!empty($e['login'])): ?><span class="err"><?= $e['login'] ?></span><?php endif; ?>

    <label>Пароль (мин. 8 символов)</label>
    <input type="password" name="pass">
    <?php if (!empty($e['pass'])): ?><span class="err"><?= $e['pass'] ?></span><?php endif; ?>

    <label>ФИО (только кириллица)</label>
    <input type="text" name="fio" value="<?= htmlspecialchars($_POST['fio'] ?? '') ?>">
    <?php if (!empty($e['fio'])): ?><span class="err"><?= $e['fio'] ?></span><?php endif; ?>

    <label>Телефон</label>
    <input type="text" name="phone" placeholder="89991234567" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
    <?php if (!empty($e['phone'])): ?><span class="err"><?= $e['phone'] ?></span><?php endif; ?>

    <label>Email</label>
    <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
    <?php if (!empty($e['email'])): ?><span class="err"><?= $e['email'] ?></span><?php endif; ?>

    <button type="submit" class="btn btn-full">Зарегистрироваться</button>
  </form>
  <p class="flink">Уже есть аккаунт? <a href="/vzhuh/login.php">Войти</a></p>
</div>
</div>

<?php require 'footer.php'; ?>
