<?php
$title = 'Вход';
require 'db.php';
require 'header.php';

$err = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = trim($_POST['login']);
    $pass  = trim($_POST['pass']);

    if (!$login || !$pass) {
        $err = 'Заполните все поля';
    } else {
        $s = $pdo->prepare('SELECT * FROM users WHERE login = ?');
        $s->execute([$login]);
        $u = $s->fetch();

        if ($u) {
            $ok = ($u['role'] == 'admin')
                ? ($pass == $u['password'])
                : password_verify($pass, $u['password']);

            if ($ok) {
                $_SESSION['uid']  = $u['id'];
                $_SESSION['name'] = $u['fio'];
                $_SESSION['role'] = $u['role'];
                header('Location: ' . ($u['role'] == 'admin' ? '/vzhuh/admin/index.php' : '/vzhuh/orders.php'));
                exit;
            }
        }
        $err = 'Неверный логин или пароль';
    }
}
?>

<div class="wrap">
<?php if (isset($_GET['ok'])): ?><div class="ok">Регистрация успешна! Войдите.</div><?php endif; ?>
<div class="fbox">
  <h2>Вход в систему</h2>
  <?php if ($err): ?><div class="bad"><?= htmlspecialchars($err) ?></div><?php endif; ?>
  <form method="POST">
    <label>Логин</label>
    <input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
    <label>Пароль</label>
    <input type="password" name="pass">
    <button type="submit" class="btn btn-full">Войти</button>
  </form>
  <p class="flink">Ещё не зарегистрированы? <a href="/vzhuh/register.php">Регистрация</a></p>
</div>
</div>

<?php require 'footer.php'; ?>
