<?php $title = 'Вжух — Таро'; require 'header.php'; ?>

<div class="slider">
  <div class="slides" id="slides">
    <div class="slide s1">
      <h1>Узнай своё будущее</h1>
      <p>Расклады карт Таро от мастеров</p>
      <a href="/vzhuh/register.php" class="btn btn-big">Начать</a>
    </div>
    <div class="slide s2">
      <h1>Любовный расклад</h1>
      <p>Что ждёт тебя в личной жизни</p>
      <a href="/vzhuh/register.php" class="btn btn-big">Заказать</a>
    </div>
    <div class="slide s3">
      <h1>Финансовый расклад</h1>
      <p>Путь к благополучию</p>
      <a href="/vzhuh/register.php" class="btn btn-big">Узнать</a>
    </div>
    <div class="slide s4">
      <h1>Творческий расклад</h1>
      <p>Раскрой свой потенциал</p>
      <a href="/vzhuh/register.php" class="btn btn-big">Попробовать</a>
    </div>
  </div>
  <button class="arr arr-l" onclick="move(-1)">&#10094;</button>
  <button class="arr arr-r" onclick="move(1)">&#10095;</button>
  <div class="dots">
    <span class="dot on" onclick="go(0)"></span>
    <span class="dot" onclick="go(1)"></span>
    <span class="dot" onclick="go(2)"></span>
    <span class="dot" onclick="go(3)"></span>
  </div>
</div>

<div class="cards">
  <div class="card"><h3>Расклады Таро</h3><p>Любовь, финансы, творчество</p></div>
  <div class="card"><h3>Удобная запись</h3><p>Выбери дату и способ оплаты</p></div>
  <div class="card"><h3>Отзывы</h3><p>Оставь отзыв после предсказания</p></div>
</div>

<script>
var cur = 0;
var total = 4;

function go(n) {
  cur = n;
  document.getElementById('slides').style.transform = 'translateX(-' + (cur * 100) + '%)';
  var dots = document.querySelectorAll('.dot');
  for (var i = 0; i < dots.length; i++) {
    dots[i].classList.remove('on');
  }
  dots[cur].classList.add('on');
}

function move(d) {
  var next = cur + d;
  if (next < 0) next = total - 1;
  if (next >= total) next = 0;
  go(next);
}

setInterval(function() { move(1); }, 3000);
</script>

<?php require 'footer.php'; ?>
