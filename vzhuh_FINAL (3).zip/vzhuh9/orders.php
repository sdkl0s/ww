<?php
$title = 'Мои заказы';
require 'db.php';
require 'header.php';
must_login();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['oid'])) {
    $pdo->prepare('UPDATE orders SET review=? WHERE id=? AND user_id=? AND status="done"')
        ->execute([trim($_POST['review']), $_POST['oid'], $_SESSION['uid']]);
    header('Location: /vzhuh/orders.php');
    exit;
}

$s = $pdo->prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC');
$s->execute([$_SESSION['uid']]);
$list = $s->fetchAll();

$sn = ['new'=>'Новый', 'in_progress'=>'В работе', 'done'=>'Предсказание готово'];
$sc = ['new'=>'b-blue', 'in_progress'=>'b-yellow', 'done'=>'b-green'];
$pn = ['cash'=>'Наличными', 'transfer'=>'Переводом'];
?>

<div class="wrap">
<div class="ph">
  <h2>Мои заказы</h2>
  <a href="/vzhuh/new_order.php" class="btn">Создать заказ</a>
</div>

<?php if (empty($list)): ?>
  <div style="text-align:center;background:#fff;border-radius:8px;padding:50px;border:1px solid #e5e7eb">
    <p style="font-size:18px;margin-bottom:14px">Заказов пока нет</p>
    <a href="/vzhuh/new_order.php" class="btn">Создать первый</a>
  </div>
<?php else: ?>
  <?php foreach ($list as $o): ?>
  <div class="ocard">
    <div class="ohead">
      <strong><?= htmlspecialchars($o['spread_type']) ?></strong>
      <span class="badge <?= $sc[$o['status']] ?>"><?= $sn[$o['status']] ?></span>
    </div>
    <div class="ometa">
      <span>Дата: <?= $o['pred_date'] ?></span>
      <span>Оплата: <?= $pn[$o['payment']] ?></span>
      <span>Тел: <?= htmlspecialchars($o['phone']) ?></span>
    </div>
    <?php if ($o['review']): ?>
      <div class="rev">Ваш отзыв: <?= htmlspecialchars($o['review']) ?></div>
    <?php elseif ($o['status'] == 'done'): ?>
      <form method="POST" style="margin-top:8px">
        <input type="hidden" name="oid" value="<?= $o['id'] ?>">
        <textarea name="review" rows="2" style="width:100%;padding:8px;border:1.5px solid #d1d5db;border-radius:6px;font-family:Arial" placeholder="Напишите отзыв..."></textarea>
        <button type="submit" class="btn btn-sm" style="margin-top:6px">Отправить отзыв</button>
      </form>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
<?php endif; ?>
</div>

<?php require 'footer.php'; ?>
