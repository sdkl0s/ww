CREATE DATABASE IF NOT EXISTS vzhuh CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vzhuh;

CREATE TABLE users (
    id       INT AUTO_INCREMENT PRIMARY KEY,
    login    VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    fio      VARCHAR(150) NOT NULL,
    phone    VARCHAR(50) NOT NULL,
    email    VARCHAR(100) NOT NULL,
    role     ENUM('user','admin') DEFAULT 'user'
);

CREATE TABLE orders (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    spread_type VARCHAR(100) NOT NULL,
    pred_date   DATE NOT NULL,
    payment     ENUM('cash','transfer') NOT NULL,
    phone       VARCHAR(50) NOT NULL,
    review      TEXT DEFAULT NULL,
    status      ENUM('new','in_progress','done') DEFAULT 'new',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

INSERT INTO users (login, password, fio, phone, email, role)
VALUES ('Admin', 'Wizard', 'Администратор', '89000000000', 'admin@mail.ru', 'admin');
