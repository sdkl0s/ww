<footer>
  <p>Вжух &copy; <?= date('Y') ?> — Гадание на картах Таро</p>
</footer>
</body>
</html>
